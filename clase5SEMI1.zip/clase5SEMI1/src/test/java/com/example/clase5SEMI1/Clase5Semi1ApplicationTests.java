package com.example.clase5SEMI1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Clase5Semi1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
