package com.example.clase5SEMI1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Clase5Semi1Application {

	public static void main(String[] args) {
		SpringApplication.run(Clase5Semi1Application.class, args);
	}

}
